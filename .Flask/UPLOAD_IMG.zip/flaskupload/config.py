UPLOAD_FOLDER = 'static/uploads'

SECRET_KEY = 'secret_key'

MAX_CONTENT_LENGTH = 16 * 1024 * 1024